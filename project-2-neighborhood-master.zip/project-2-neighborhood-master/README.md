# project-2-neighborhood

### Grass is Greener App
Find the area to live or visit that suits your lifestyle 

### Description
An app to show and log the "feel" of an area, based on user inputs through survey questionss like "How is the wildlife in the area?"
An app to show and log the "vibe" of an area, based on user inputs through survey questions and tags.

Users will take a fun survey about where they live, and about where they visit. The app will gather the data and generate an average consensus of the area. Using this data, users can decide where to live, vacation, or hang out, based on what's important to them.

### Sketch
To be added

### APIs Used
Zillow
Google Maps


### Tasks
