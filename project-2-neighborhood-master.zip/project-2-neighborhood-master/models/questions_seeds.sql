INSERT INTO question(tag, category)
VALUES ("unique_bars", "social");

INSERT INTO question(tag, category)
VALUES ("live_music", "social");

INSERT INTO question(tag, category)
VALUES ("great_shopping", "social");

INSERT INTO question(tag, category)
VALUES (" dog_walking_clubs", "social");

INSERT INTO question(tag, category)
VALUES ("many_young_people", "social");

INSERT INTO question(tag, category)
VALUES ("too_crowded", "social");

INSERT INTO question(tag, category)
VALUES ("feels_safe", "social");

INSERT INTO question(tag, category)
VALUES ("feels_dangerous", "social");

INSERT INTO question(tag, category)
VALUES ("kind_of_empty", "social");

INSERT INTO question(tag, category)
VALUES ("friendly_people", "social");

INSERT INTO question(tag, category)
VALUES ("too_many_hipsters", "social");

INSERT INTO question(tag, category)
VALUES ("snobby_people", "social");

INSERT INTO question(tag, category)
VALUES ("scenic_tours", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("historical_markers", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("lots_of_wildlife", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("old_houses", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("outdoor_murals", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("sculpture_gardens", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("modern_buildings", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("beautiful_sunsets", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("distinct_skyline", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("many_wildflowers", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("bland", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("needs_upkeep", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("smells_bad", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("industrial_area", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("undeveloped_land", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("lots_of_graffiti", "aesthetics");

INSERT INTO question(tag, category)
VALUES ("annual_parade", "activities");

INSERT INTO question(tag, category)
VALUES ("bike_trails", "activities");

INSERT INTO question(tag, category)
VALUES ("fireworks_show", "activities");

INSERT INTO question(tag, category)
VALUES ("community_car_show", "activities");

INSERT INTO question(tag, category)
VALUES ("weekly_volunteering events", "activities");

INSERT INTO question(tag, category)
VALUES ("monthly_craft_fairs", "activities");

INSERT INTO question(tag, category)
VALUES ("guided_tours", "activities");

INSERT INTO question(tag, category)
VALUES ("many_gyms", "activities");

INSERT INTO question(tag, category)
VALUES ("pedestrian_friendly", "activities");

INSERT INTO question(tag, category)
VALUES ("rock_climbing", "activities");
