USE grass_is_greener_db;
INSERT INTO answers(user_name, zip_code, person_type, answer, questionID, createdAt, updatedAt)
VALUES ("bill", "75165", "resident", true, 1, DEFAULT, DEFAULT);

INSERT INTO answers(user_name, zip_code, person_type, answer, questionID, createdAt, updatedAt)
VALUES ("john", "75165", "resident", true, 1, DEFAULT, DEFAULT);

INSERT INTO answers(user_name, zip_code, person_type, answer, questionID, createdAt, updatedAt)
VALUES ("adam", "75165", "resident", false, 1, DEFAULT, DEFAULT);

INSERT INTO answers(user_name, zip_code, person_type, answer, questionID, createdAt, updatedAt)
VALUES ("jason", "75165", "visitor", false, 1, DEFAULT, DEFAULT);

INSERT INTO answers(user_name, zip_code, person_type, answer, questionID, createdAt, updatedAt)
VALUES ("kyle", "75165", "visitor", false, 1, DEFAULT, DEFAULT);

INSERT INTO answers(user_name, zip_code, person_type, answer, questionID, createdAt, updatedAt)
VALUES ("perry", "75165", "visitor", false, 1, DEFAULT, DEFAULT);